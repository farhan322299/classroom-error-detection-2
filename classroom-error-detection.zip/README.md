# Classroom Message Transmission Error Detection System

A polished web application for a **Computer Networks / Data Communication**
laboratory project. A faculty member composes a classroom announcement, the
message is "transmitted" through a simulated noisy channel that randomly
flips bits, and the receiver uses a real error-detection algorithm to
find out whether the message arrived unchanged.

## Techniques implemented (from scratch in Python)

| Method | Idea |
|---|---|
| **CRC-8** | The message is divided by a generator polynomial (`0x07`, init `0xFF`). The remainder is the CRC code. Receiver divides again and compares remainders. |

## Features

- 🧪 Fully working sender → encoder → noisy channel → receiver → students pipeline
- 🌩️ Noise simulation with four levels (None / Low / Medium / High)
- 🔁 Optional **random seed** — identical seeds reproduce the exact same corruption
- 🟢🔴 Live status: "No Error Detected" vs "Transmission Error Detected!"
- 🔍 Bit-level comparison with animated highlighting of changed bits/bytes
- 📊 Session dashboard: messages sent, bits changed, errors detected, detection rate
- 🕘 Transmission history, replay-same-noise, reset, toasts, fully responsive UI

## Project structure

```text
classroom-error-detection/
├── app.py                 Flask backend + /api/transmit
├── algorithms/
│   ├── crc.py             CRC-8 polynomial division
│   └── selfcheck.py       Algorithm self-tests (python -m algorithms.selfcheck)
├── templates/
│   └── index.html         Single-page app (all sections)
├── static/
│   ├── css/style.css      Dark glassmorphism dashboard theme
│   └── js/script.js       UI logic, API calls, results rendering
├── requirements.txt
└── test_app.py            Integration tests (Flask test client)
```

## Run locally

```bash
# 1. create a virtual environment (recommended)
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate    # macOS / Linux

# 2. install dependencies
pip install -r requirements.txt

# 3. run
python app.py
```

Open **http://127.0.0.1:5000** in your browser.

## Run the tests

```bash
python -m algorithms.selfcheck   # verify the CRC-8 algorithm
python test_app.py               # verify the Flask API end-to-end
```

## How the simulation works

1. The message is encoded to UTF-8 bytes → binary bits.
2. The sender computes the error-detection code (CRC-8).
3. The channel flips random bits (seeded `random` module), proportional to the
   chosen noise level.
4. The receiver re-computes the code from the received bytes and compares it
   with the transmitted code. Mismatch ⇒ corruption; match ⇒ accept.

The error-detection code itself travels uncorrupted so the demo isolates the
question of whether the *message* integrity can be verified by recomputation.

## API

`POST /api/transmit`

```json
{ "message": "Mid-semester examinations begin on Monday at 10 AM.",
  "method": "crc",
  "noise": "medium",
  "seed": 42 }
```

Returns original + received text, both codes, flipped bit positions, change
highlight ranges, detection status, and a plain-language explanation.