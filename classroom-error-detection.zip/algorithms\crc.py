"""CRC (Cyclic Redundancy Check) — CRC-8 with polynomial x^8 + x^2 + x + 1.

The message bytes are treated as a single long binary number and divided by
a generator polynomial (0x07, init 0xFF). The remainder is the 8-bit CRC
code. Bit-level polynomial division is implemented as a shift-register
(XOR) loop. The receiver repeats the division; any difference between the
transmitted and recomputed remainder signals corruption.
"""

POLY = 0x07
INIT = 0xFF


def crc8(data: bytes) -> int:
    """Compute the 8-bit CRC remainder of `data`."""
    crc = INIT
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ POLY) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return crc


def encode(data: bytes) -> str:
    """Return the CRC remainder as an 8-bit binary string."""
    return format(crc8(data), "08b")


def verify(data: bytes, code: str) -> dict:
    """Recompute CRC of received bytes and compare with the transmitted code.

    Returns {'match': bool, 'recomputed_remainder': int, 'transmitted_remainder': int}.
    """
    recomputed = crc8(data)
    transmitted = int(code, 2)
    return {"match": recomputed == transmitted, "recomputed_remainder": recomputed, "transmitted_remainder": transmitted}