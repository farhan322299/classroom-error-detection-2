"""Self-check for the CRC-8 error-detection algorithm.

Run:  python -m algorithms.selfcheck
"""

from algorithms import crc

MESSAGE = "Mid-semester examinations begin on Monday at 10 AM."
DATA = MESSAGE.encode("utf-8")
FLIPPED = bytes(b ^ 0x10 if i == 3 else b for i, b in enumerate(DATA))

code = crc.encode(DATA)
assert crc.verify(DATA, code)["match"], "clean message rejected"
assert not crc.verify(FLIPPED, code)["match"], "corrupted message accepted"
assert crc.encode(DATA) == crc.encode(DATA), "not deterministic"
print(f"crc code={code}  clean={crc.verify(DATA, code)['match']}  flipped={not crc.verify(FLIPPED, code)['match']}")

print("All algorithm self-checks passed.")