"""Classroom Message Transmission Error Detection System.

A Flask web app that simulates an error-detection scheme over a noisy
communication channel: the sender encodes a message, noise flips random
bits, and the receiver recomputes and compares the code.
"""

import difflib
import random

from flask import Flask, jsonify, render_template, request

from algorithms import crc

app = Flask(__name__)

METHODS = {
    "crc": {
        "name": "CRC (Cyclic Redundancy Check)",
        "encode": crc.encode,
        "verify": crc.verify,
    },
}

# Fraction of bits we intentionally corrupt at each noise level.
NOISE_RATES = {"none": 0.0, "low": 0.015, "medium": 0.035, "high": 0.06}
NOISE_FLOOR = {"none": 0, "low": 1, "medium": 2, "high": 3}


def bits_of(byte: int) -> list[int]:
    """Return the 8 individual bits of `byte`, most significant first."""
    return [(byte >> shift) & 1 for shift in range(7, -1, -1)]


def int_from_bits(bits: list[int]) -> int:
    value = 0
    for bit in bits:
        value = (value << 1) | bit
    return value


def apply_noise(message: str, rate: float, floor: int, rng: random.Random):
    """Inject bit noise and return everything needed to rebuild the message.

    Returns (chars, positions, received_bytes, received_text).
    """
    chars = list(message)
    char_bytes = [char.encode("utf-8") for char in chars]

    payload: list[int] = []
    for text in char_bytes:
        for byte in text:
            payload.extend(bits_of(byte))

    n_bits = len(payload)
    flips = 0 if rate == 0 else max(floor, round(n_bits * rate))
    positions = rng.sample(range(n_bits), flips) if flips else []
    for position in positions:
        payload[position] ^= 1

    received_bytes = bytes(
        int_from_bits(payload[i:i + 8]) for i in range(0, n_bits, 8)
    )
    try:
        received_text = received_bytes.decode("utf-8")
    except UnicodeDecodeError:
        received_text = received_bytes.decode("utf-8", errors="replace")

    return chars, positions, received_bytes, received_text


def changed_char_ranges(original: str, received: str) -> list[list[int]]:
    """Indices [start, end) in the original message that were altered."""
    matcher = difflib.SequenceMatcher(None, original, received, autojunk=False)
    ranges = []
    for tag, i1, i2, _j1, _j2 in matcher.get_opcodes():
        if tag in ("replace", "delete"):
            ranges.append([i1, i2])
    return ranges


def build_explanation(method: str, msgs: dict) -> str:
    """Plain-language account of how the selected method flagged the error."""
    name = METHODS[method]["name"]
    sender_code = msgs["sender_code"]
    receiver_code = msgs["receiver_code"]
    detail = msgs["detail"]
    detected = msgs["detected"]

    if not detected:
        return (
            f"The {name} code recalculated from the received message ({receiver_code}) "
            f"exactly matches the code transmitted by the sender ({sender_code}). "
            f"The receiver therefore accepts the message as unchanged — no error is "
            f"detected, even though the noisy channel altered {msgs['flips']} bit(s)."
        )

    return (
        f"The sender divided the message by the CRC generator polynomial and "
        f"transmitted the remainder ({sender_code}). The receiver repeated the "
        f"polynomial division on the received bytes and obtained remainder "
        f"{detail['recomputed_remainder']} ({receiver_code}), which differs from the "
        f"transmitted remainder ({sender_code}). A difference in the remainder means "
        f"the data changed during transmission."
    )


def missed_note(msgs: dict) -> str | None:
    """Explain honestly when noise corrupted data but the method missed it."""
    if msgs["flips"] and not msgs["detected"]:
        return (
            "Note: the channel did corrupt bits, but this method did not flag them. "
            "CRC-8 can still miss rare error patterns that leave the remainder unchanged. "
            "Real networks therefore use stronger codes such as CRC-32."
        )
    return None


def pack_bits(byte_list: list[int]) -> str:
    return " ".join(format(byte, "08b") for byte in byte_list)


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route("/api/transmit", methods=["POST"])
def transmit():
    data = request.get_json(force=True, silent=True) or {}
    message = (data.get("message") or "").strip()
    method = data.get("method", "crc")
    noise = data.get("noise", "medium")
    seed = data.get("seed")

    if not message:
        return jsonify({"ok": False, "error": "Please enter a message first."}), 400
    if method not in METHODS:
        return jsonify({"ok": False, "error": f"Unknown method: {method}"}), 400
    if noise not in NOISE_RATES:
        return jsonify({"ok": False, "error": f"Unknown noise level: {noise}"}), 400

    seed = seed if isinstance(seed, int) else random.randint(0, 2**31 - 1)
    rng = random.Random(seed)

    try:
        chars, positions, received_bytes, received_text = apply_noise(
            message, NOISE_RATES[noise], NOISE_FLOOR[noise], rng
        )
    except Exception as exc:  # e.g. unterminated surrogates in input
        return jsonify({"ok": False, "error": f"Could not encode message: {exc}"}), 400

    original_bytes = b"".join(char.encode("utf-8") for char in chars)

    encode = METHODS[method]["encode"]
    sender_code = encode(original_bytes)
    receiver_code = encode(received_bytes)

    detected = sender_code != receiver_code
    detail = METHODS[method]["verify"](received_bytes, sender_code)

    changed_bits = []
    changed_bytes = []
    for position in positions:
        byte_index, bit_in_byte = divmod(position, 8)
        changed_bits.append([byte_index, bit_in_byte])
        if byte_index not in changed_bytes:
            changed_bytes.append(byte_index)

    msgs = {
        "sender_code": sender_code,
        "receiver_code": receiver_code,
        "detected": detected,
        "detail": detail,
        "flips": len(positions),
    }

    return jsonify({
        "ok": True,
        "method": method,
        "method_name": METHODS[method]["name"],
        "noise": noise,
        "seed": seed,
        "flips": len(positions),
        "original_text": message,
        "received_text": received_text,
        "changed_char_ranges": changed_char_ranges(message, received_text),
        "changed_bits": changed_bits,
        "changed_bytes": sorted(set(changed_bytes)),
        "sender_code": sender_code,
        "receiver_code": receiver_code,
        "detected": detected,
        "status": "error" if detected else "clean",
        "explanation": build_explanation(method, msgs),
        "missed_note": missed_note(msgs),
        "method_detail": detail,
        "bits_original": pack_bits(list(original_bytes)),
        "bits_received": pack_bits(list(received_bytes)),
    })


if __name__ == "__main__":
    app.run(debug=True, port=5000)