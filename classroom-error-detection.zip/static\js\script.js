/* Classroom Message Transmission Error Detection System — frontend logic */

(() => {
  "use strict";

  const API = "/api/transmit";

  const state = {
    method: "crc",
    noise: "low",
    seedUsed: null,
    lastPayload: null,
    stats: { sent: 0, bits: 0, noisy: 0, detected: 0 },
    history: [],
  };

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => [...document.querySelectorAll(sel)];

  const METHOD_NAMES = {
    crc: "CRC",
  };
  const NOISE_LABEL = {
    none: "No Error",
    low: "Low",
    medium: "Medium",
    high: "High",
  };
  const NOISE_WIDTH = { none: "0%", low: "30%", medium: "55%", high: "90%" };

  /* ---------------- toasts ---------------- */
  function toast(text, kind = "") {
    const box = $("#toasts");
    const el = document.createElement("div");
    el.className = `toast ${kind}`;
    el.innerHTML = `<span>${text}</span><button class="t-close" aria-label="dismiss">×</button>`;
    box.appendChild(el);
    el.querySelector(".t-close").addEventListener("click", () => dismiss(el));
    setTimeout(() => dismiss(el), 5200);
  }
  function dismiss(el) {
    el.classList.add("leaving");
    setTimeout(() => el.remove(), 300);
  }

  /* ---------------- input wiring ---------------- */
  function bindInputs() {
    const msg = $("#message");
    const updateCount = () => {
      $("#charCount").textContent = msg.value.length;
    };
    msg.addEventListener("input", updateCount);
    updateCount();

    $$("#methodCards .method-card").forEach((card) => {
      card.addEventListener("click", () => {
        $$("#methodCards .method-card").forEach((c) => c.classList.remove("is-selected"));
        card.classList.add("is-selected");
        state.method = card.dataset.method;
      });
    });

    $$("#noiseSeg button").forEach((btn) => {
      btn.addEventListener("click", () => {
        $$("#noiseSeg button").forEach((b) => b.classList.remove("is-selected"));
        btn.classList.add("is-selected");
        state.noise = btn.dataset.noise;
        $("#noiseBar").style.width = NOISE_WIDTH[state.noise];
      });
    });

    $("#navToggle").addEventListener("click", () => {
      $("#navLinks").classList.toggle("open");
    });

    $("#startSim").addEventListener("click", () => {
      $("#simulation").scrollIntoView({ behavior: "smooth" });
      $("#message").focus();
    });
  }

  /* ---------------- transmission ---------------- */
  function currentPayload(seed) {
    return {
      message: $("#message").value,
      method: state.method,
      noise: state.noise,
      seed: seed,
    };
  }

  async function transmit(payload) {
    const btn = $("#transmitBtn");
    const btnLabel = btn.querySelector(".btn-label");
    const spinner = btn.querySelector(".spinner");
    btn.disabled = true;
    btnLabel.textContent = "Transmitting…";
    spinner.hidden = false;
    $("#flowTrack").classList.add("transmitting");
    $("#flowPacket").classList.add("anim");

    try {
      const [res] = await Promise.all([
        fetch(API, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }),
        new Promise((r) => setTimeout(r, 950)),
      ]);
      const data = await res.json();
      if (!res.ok || !data.ok) {
        toast(data.error || "Transmission failed.", "error");
        return;
      }
      render(data);
      toast(data.detected ? "🔴 Transmission error detected!" : "🟢 Message received intact.", data.detected ? "error" : "ok");
    } catch (err) {
      console.error(err);
      toast("Could not reach the server. Is the Flask app running?", "error");
    } finally {
      btn.disabled = false;
      btnLabel.textContent = "📡 Transmit Message";
      spinner.hidden = true;
      $("#flowTrack").classList.remove("transmitting");
      setTimeout(() => $("#flowPacket").classList.remove("anim"), 900);
    }
  }

  function doTransmit(seed) {
    const payload = currentPayload(seed);
    if (!payload.message.trim()) {
      toast("Please enter a classroom announcement first.", "error");
      $("#message").focus();
      return;
    }
    state.lastPayload = payload;
    transmit(payload);
  }

  /* ---------------- rendering ---------------- */
  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function highlightText(text, ranges) {
    if (!ranges.length) return escapeHtml(text);
    const chars = [...text];
    const marks = ranges.map(([start, end]) => ({ start, end }));
    let html = "";
    for (let i = 0; i < chars.length; i++) {
      const inside = marks.some((m) => i >= m.start && i < m.end);
      const open = marks.some((m) => m.start === i);
      const close = marks.some((m) => m.end === i + 1 && i >= m.start);
      if (open) html += '<span class="changed">';
      html += escapeHtml(chars[i]);
      if (close && inside) html += "</span>";
    }
    return html;
  }

  function byteDirty(byteIdx, changedBits) {
    return changedBits.some(([b]) => b === byteIdx);
  }

  function renderBits(el, bitsStr, changedBits) {
    const groups = bitsStr.split(" ");
    el.innerHTML = groups
      .map((byte, bi) => {
        const has = byteDirty(bi, changedBits);
        const cells = [...byte.padStart(8, "0")]
          .map((b, i) => (changedBits.some(([bb, ii]) => bb === bi && ii === i) ? `<b class="bit changed">${b}</b>` : `<span class="bit">${b}</span>`))
          .join("");
        return `<span class="bin-byte${has ? " dirty" : ""}">${cells}</span>`;
      })
      .join("");
  }

  function render(d) {
    state.seedUsed = d.seed;

    /* report header meta */
    $("#resultMeta").textContent =
      `${METHOD_NAMES[d.method]} · Noise: ${NOISE_LABEL[d.noise]} · Bits flipped: ${d.flips} · Seed: ${d.seed}`;

    /* three columns */
    $("#rcOriginalText").innerHTML = highlightText(d.original_text, []);
    $("#rcChannelText").innerHTML = "⚠ " + (d.flips ? escapeHtml(d.received_text) : "Message passed through unaffected.");
    $("#rcReceivedText").innerHTML = highlightText(d.received_text, d.changed_char_ranges);
    $("#rcFlips").textContent = d.flips;
    $("#rcSenderCode").textContent = d.sender_code;
    $("#rcReceiverCode").textContent = d.receiver_code;

    /* receiver preview */
    const preview = $("#previewCard");
    preview.classList.remove("clean", "error");
    preview.classList.add(d.detected ? "error" : "clean");
    $("#previewLed").style.background = d.detected ? "var(--bad)" : "var(--ok)";
    $("#previewTitle").textContent = d.detected
      ? "Error DETECTED — message rejected"
      : "Message accepted — codes match";
    $("#previewCode").textContent = d.receiver_code;
    $("#previewBits").textContent = d.bits_received.replace(/ /g, "");

    /* status card */
    const statusCard = $("#statusCard");
    statusCard.classList.remove("clean", "error");
    statusCard.classList.add(d.detected ? "error" : "clean");
    $("#statusPill").textContent = d.detected ? "TRANSMISSION ERROR DETECTED" : "NO ERROR DETECTED";
    $("#statusTitle").textContent = d.detected
      ? "🔴 Transmission Error Detected!"
      : "🟢 Message Received Successfully — No Error Detected";
    $("#statusSub").textContent = d.detected
      ? `The ${METHOD_NAMES[d.method]} code computed by the receiver does not match the sender's. The message was corrupted at ${d.flips} bit position(s).`
      : `The ${METHOD_NAMES[d.method]} code recomputed by the receiver exactly matches the sender's code.`;

    /* binary comparison */
    $("#binwrap").hidden = false;
    renderBits($("#bitsOriginal"), d.bits_original, d.changed_bits);
    renderBits($("#bitsReceived"), d.bits_received, d.changed_bits);

    /* explanation */
    $("#explain").hidden = false;
    $("#explainText").textContent = d.explanation;
    const missed = $("#missedNote");
    if (d.missed_note) {
      missed.hidden = false;
      missed.textContent = d.missed_note;
    } else {
      missed.hidden = true;
    }

    /* show section + controls */
    $("#results").hidden = false;
    $("#againBtn").hidden = false;
    $("#replayBtn").hidden = !d.flips;
    $("#replayBtn").disabled = !d.flips;
    $("#replayBtn2").hidden = !d.flips;
    $("#replayBtn2").disabled = !d.flips;
    $("#results").scrollIntoView({ behavior: "smooth", block: "start" });

    /* statistics + history */
    updateStats(d);
  }

  /* ---------------- statistics & history ---------------- */
  function updateStats(d) {
    const s = state.stats;
    s.sent += 1;
    s.bits += d.flips;
    if (d.flips) {
      s.noisy += 1;
      if (d.detected) s.detected += 1;
    }

    $("#stSent").textContent = s.sent;
    $("#stBits").textContent = s.bits;
    $("#stErrors").textContent = s.noisy;
    $("#stDetected").textContent = s.detected;
    $("#stRate").textContent = s.noisy ? Math.round((s.detected / s.noisy) * 100) + "%" : "—";

    /* bars */
    const max = Math.max(s.noisy, s.detected, 1);
    $("#barIntro").style.width = (s.noisy / max) * 100 + "%";
    $("#barDet").style.width = (s.detected / max) * 100 + "%";
    $("#barIntroN").textContent = s.noisy;
    $("#barDetN").textContent = s.detected;

    /* history */
    state.history.unshift({
      method: METHOD_NAMES[d.method],
      noise: NOISE_LABEL[d.noise],
      flips: d.flips,
      detected: d.detected,
      time: new Date().toLocaleTimeString(),
    });
    if (state.history.length > 40) state.history.pop();
    renderHistory();
  }

  function renderHistory() {
    const list = $("#historyList");
    if (!state.history.length) {
      list.innerHTML = '<div class="history-empty">No transmissions yet — run your first simulation above.</div>';
      return;
    }
    list.innerHTML = state.history
      .map(
        (h) => `
      <div class="history-row">
        <span class="h-row-status ${h.detected ? "bad" : "ok"}"></span>
        <div class="h-row-main">
          <strong>${escapeHtml(h.method)}</strong>
          <span>${escapeHtml(h.noise)} noise · ${h.flips} bit(s) flipped</span>
          <span>${escapeHtml(h.time)}</span>
        </div>
        <div class="h-row-badges">
          <span class="chip ${h.detected ? "error" : "clean"}">${h.detected ? "ERROR DETECTED" : "CLEAN"}</span>
        </div>
      </div>`
      )
      .join("");
  }

  function resetAll(full) {
    state.seedUsed = null;
    state.lastPayload = null;
    state.stats = { sent: 0, bits: 0, noisy: 0, detected: 0 };
    state.history = [];
    $("#results").hidden = true;
    updateStatsUI();
    renderHistory();
    if (full) {
      $("#message").value =
        "Mid-semester examinations begin on Monday at 10 AM at the Main Auditorium. All students must carry their hall tickets.";
      $("#charCount").textContent = $("#message").value.length;
      setupDefaults();
      toast("Simulation reset. Ready for a new transmission.", "ok");
    }
  }

  function updateStatsUI() {
    const s = state.stats;
    $("#stSent").textContent = s.sent;
    $("#stBits").textContent = s.bits;
    $("#stErrors").textContent = s.noisy;
    $("#stDetected").textContent = s.detected;
    $("#stRate").textContent = s.noisy ? Math.round((s.detected / s.noisy) * 100) + "%" : "—";
    $("#barIntro").style.width = "0%";
    $("#barDet").style.width = "0%";
    $("#barIntroN").textContent = s.noisy;
    $("#barDetN").textContent = s.detected;
  }

  function setupDefaults() {
    $$("#methodCards .method-card").forEach((c) => c.classList.toggle("is-selected", c.dataset.method === "crc"));
    $$("#noiseSeg button").forEach((b) => b.classList.toggle("is-selected", b.dataset.noise === "low"));
    state.method = "crc";
    state.noise = "low";
    $("#noiseBar").style.width = NOISE_WIDTH.low;
  }

  /* ---------------- wire actions ---------------- */
  function bindActions() {
    $("#transmitBtn").addEventListener("click", () => doTransmit(null));
    $("#replayBtn").addEventListener("click", () => doTransmit(state.seedUsed));
    $("#replayBtn2").addEventListener("click", () => doTransmit(state.seedUsed));
    $("#againBtn").addEventListener("click", () => doTransmit(null));
    $("#resetBtn").addEventListener("click", () => resetAll(false));
    $("#navReset").addEventListener("click", () => resetAll(true));
    $("#clearHistory").addEventListener("click", () => {
      state.history = [];
      renderHistory();
      toast("Transmission history cleared.");
    });
  }

  /* ---------------- boot ---------------- */
  bindInputs();
  bindActions();
  renderHistory();
  setupDefaults();
})();