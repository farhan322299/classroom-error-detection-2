"""Integration check for the Flask app (no server process needed).

Run:  python test_app.py
"""

import json

from app import app

client = app.test_client()

assert client.get("/").status_code == 200


def transmit(payload):
    res = client.post("/api/transmit", data=json.dumps(payload), content_type="application/json")
    assert res.status_code == 200, res.get_data(as_text=True)
    return res.get_json()


# deterministic corruptions across every noise level
for noise in ("none", "low", "medium", "high"):
    d = transmit({"message": "Mid-semester examinations begin on Monday at 10 AM.",
                  "method": "crc", "noise": noise, "seed": 42})
    assert d["ok"], f"{noise}: failed"
    assert (d["flips"] > 0) == (noise != "none"), f"{noise}: wrong flip count"
    assert d["status"] in ("clean", "error")
    assert d["detected"] == (d["status"] == "error")
    assert isinstance(d["sender_code"], str) and isinstance(d["receiver_code"], str)
    assert len(d["sender_code"]) == 8, "CRC: 8-bit code expected"
print("all noise levels OK")

# deterministic => same seed reproduces the exact same corruption
a = transmit({"message": "Timetable changed: Math on Friday.", "method": "crc", "noise": "medium", "seed": 7})
b = transmit({"message": "Timetable changed: Math on Friday.", "method": "crc", "noise": "medium", "seed": 7})
assert a["received_text"] == b["received_text"] and a["changed_bits"] == b["changed_bits"]
print("seed reproducibility OK")

# validations
assert transmit({"method": "crc", "noise": "low", "message": "x", "seed": 1})
assert client.post("/api/transmit", data=json.dumps({"method": "crc", "noise": "low", "message": "   ", "seed": 1}),
                   content_type="application/json").status_code == 400
assert client.post("/api/transmit", data=json.dumps({"method": "nope", "noise": "low", "message": "x", "seed": 1}),
                   content_type="application/json").status_code == 400
assert client.post("/api/transmit", data=json.dumps({"method": "crc", "noise": "loud", "message": "x", "seed": 1}),
                   content_type="application/json").status_code == 400
print("validation checks OK")

# Unicode message survives roundtrip
d = transmit({"message": "Assignment 3: deadline Friday 23:59. Σ = 3.14 ✅", "method": "crc", "noise": "none", "seed": 1})
assert d["received_text"] == d["original_text"] and not d["detected"]
print("unicode + no-noise OK")

print("ALL APP INTEGRATION CHECKS PASSED")